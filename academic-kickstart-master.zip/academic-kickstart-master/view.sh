#!/usr/bin/env bash

hugo --i18n-warnings server
