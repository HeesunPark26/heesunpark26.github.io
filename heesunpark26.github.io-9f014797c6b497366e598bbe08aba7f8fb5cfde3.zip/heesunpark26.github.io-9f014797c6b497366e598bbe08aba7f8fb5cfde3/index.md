

# About me

I'm a senior undergraduate in the College of Liberal Studies at SNU, majoring in Philosophy and Biology. I am broadly interested in cognitive neuroscience and consciousness, and how we can better understand how the brain works through computational approaches. 

&nbsp;


### Seoul National University
B.A., Philosophy & B.S., Biological science Mar, 2014 - Current

